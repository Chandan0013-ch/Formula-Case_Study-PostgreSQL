

drop table if exists results;
drop table if exists sprint_results; 
drop table if exists constructor_results; 
drop table if exists constructor_standings;
drop table if exists driver_standings; 
drop table if exists lap_times; 
drop table if exists pit_stops; 
drop table if exists qualifying; 
drop table if exists races; 
drop table if exists circuits;
drop table if exists constructors;
drop table if exists drivers;	
drop table if exists status; 
drop table if exists seasons; 
