
select now();
select pg_sleep(1);

\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/drop_tables.sql;


\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/ddl.sql;


\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/seasons.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/status.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/circuits.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/races.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/drivers.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/constructors.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/constructor_results.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/constructor_standings.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/driver_standings.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/pit_stops.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/qualifying.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/results.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/sprint_results.sql;


\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_1.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_2.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_3.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_4.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_5.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_6.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_7.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_8.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_9.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_10.sql;
\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/lap_times_11.sql;


\i /Users/thoufiq/THOUFIQ/Lighthall/2023/SQL_Bootcamp_2023_Cohort1/Case_Study/Formula1/Dataset/INSERT_Scripts/pr_validate_count.sql;

call pr_validate_count();

select now();
select 'Completed!' as "Status";

